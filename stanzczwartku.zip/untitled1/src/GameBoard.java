import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.List;
import java.awt.Point;
import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Comparator;

import static java.lang.Math.floor;

public class GameBoard extends JPanel implements MouseListener, KeyListener {
    private Player player;
    private int[][] map;
    private Room.sciana pokoj1 = new Room.sciana();
    private Room.schodzydol dol = new Room.schodzydol();

    private Djikstra djikstra;
    private int highlightedX = -1; // Współrzędna x klikniętego kafelka
    private int highlightedY = -1; // Współrzędna y klikniętego kafelka

    public GameBoard() {
        player = new Player(450, 950);
        setFocusable(true); // Ustawienie panelu jako aktywnego, aby mógł otrzymywać zdarzenia klawiatury
        addKeyListener(this); // Dodanie KeyListener do panelu

        // Inicjalizacja mapy i dodanie obsługi myszy
        this.map = generateFloorMap();
        addMouseListener(this);

        int[] randomNumbersss = new int[4];
        for (int i = 0; i < 4; i++) {
            randomNumbersss[i] = 50 * (int) (floor(Math.random() * 18) + 1);
        }
        dol.setxz(new int[][]{
                {randomNumbersss[0],randomNumbersss[1]}
        });

        skibidimapa();
        int[][] graph = generateFloorMap(); // You need to implement this method to generate a graph
        djikstra = new Djikstra(graph);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        int squareSize = 50;
        g.setColor(Color.RED);

        int[][] map = new int[20 * 20][2]; // Tablica 20x20 kwadratów podłogi
        int index = 0;

        for (int x = 0; x < 20; x++) {
            for (int y = 0; y < 20; y++) {
                // Ustawianie współrzędnych każdego kwadratu podłogi
                map[index][0] = x * 50; // Współrzędna x
                map[index][1] = y * 50; // Współrzędna y
                index++;
            }
        }

        for (int[] coords : pokoj1.xz) {
            // Iterujesz po polach z pokoj1
            int indexToRemove = -1;
            for (int i = 0; i < map.length; i++) {
                // Sprawdzasz, czy pole z pokoj1 występuje w mapie
                if (map[i][0] == coords[0] && map[i][1] == coords[1]) {
                    indexToRemove = i; // Zapamiętujesz indeks pola do usunięcia
                    break; // Przerywasz pętlę, gdy znajdziesz pasujące pole
                }
            }
            if (indexToRemove != -1) {
                // Usuwasz pole z mapy, jeśli zostało znalezione w pokoj1
                map[indexToRemove][0] = -1; // Możesz oznaczyć usunięte pole jakąś wartością, na przykład -1
                map[indexToRemove][1] = -1;
            }
        }
        int[][] dolTiles = dol.getxz();

// Iteracja przez kafelki z dol
        for (int i = 0; i < dolTiles.length; i++) {
            int[] dolTile = dolTiles[i];
            int dolX = dolTile[0];
            int dolY = dolTile[1];

            // Iteracja przez kafelki z map
            for (int j = 0; j < map.length; j++) {
                int[] mapTile = map[j];
                int mapX = mapTile[0];
                int mapY = mapTile[1];

                // Jeśli kafelki mają te same współrzędne, to usuwamy kafelek z map
                if (dolX == mapX && dolY == mapY) {
                    // Usuwanie kafelka z map
                    // Tutaj zależy od tego, jak jest zaimplementowana mapa, aby usunąć kafelek z map
                    // Może to być np. map.remove(j) lub oznaczenie kafelka jako pusty, w zależności od implementacji mapy
                }
            }
        }

        g.setColor(Color.BLUE);
        // Teraz możesz rysować tylko te pola z mapy, które nie występują w pokoj1
        for (int i = 0; i < map.length; i++) {
            if (map[i][0] != -1 && map[i][1] != -1) {
                // Rysuj tylko te pola, które nie zostały oznaczone jako usunięte
                g.fillRect(map[i][0], map[i][1], squareSize, squareSize);
            }
        }

        g.setColor(Color.RED);
        for (int i = 0; i < pokoj1.xz.length; i++) {
            g.fillRect(pokoj1.xz[i][0], pokoj1.xz[i][1], squareSize, squareSize);
        }

        // Rysuj gracza
        g.setColor(Color.GREEN);
        g.fillRect(player.getX(), player.getY(), squareSize, squareSize);

        // Jeśli współrzędne klikniętego kafelka są ustawione, podświetl go
        if (highlightedX != -1 && highlightedY != -1) {
            g.setColor(Color.YELLOW);
            g.fillRect(highlightedX, highlightedY, squareSize, squareSize);
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int keyCode = e.getKeyCode();
        int newX = player.getX(); // Współrzędna x docelowego pola gracza
        int newY = player.getY(); // Współrzędna y docelowego pola gracza

        switch (keyCode) {
            case KeyEvent.VK_UP:
                // Sprawdzamy, czy gracz ma miejsce, aby się poruszyć do góry
                if (newY - 50 >= 0) {
                    // Jeśli tak, przesuwamy gracza do góry
                    newY-=50;
                }
                break;
            case KeyEvent.VK_DOWN:
                // Sprawdzamy, czy gracz ma miejsce, aby się poruszyć w dół
                if (newY + 50 < getHeight()) {
                    newY+=50;
                }
                break;
            case KeyEvent.VK_LEFT:
                // Sprawdzamy, czy gracz ma miejsce, aby się poruszyć w lewo
                if (newX - 50 >= 0) {
                    // Jeśli tak, przesuwamy gracza w lewo
                    newX -= 50;
                }
                break;
            case KeyEvent.VK_RIGHT:
                // Sprawdzamy, czy gracz ma miejsce, aby się poruszyć w prawo
                if (newX + 50 < getWidth()) {
                    // Jeśli tak, przesuwamy gracza w prawo
                    newX += 50;
                }
                break;
        }

        // Sprawdź, czy nowe współrzędne gracza nie należą do pokoj1.xz
        for (int[] coords : pokoj1.xz) {
            if (coords[0] == newX && coords[1] == newY) {
                // Jeśli współrzędne nowego pola są takie same jak współrzędne pola w pokoj1.xz,
                // oznacza to, że pole jest zajęte, więc nie przesuwamy gracza
                return;
            }
        }


        // Jeśli dotarliśmy tutaj, oznacza to, że pole jest wolne, więc możemy przesunąć gracza
        player.setX(newX); // Ustaw nową współrzędną x gracza
        player.setY(newY); // Ustaw nową współrzędną y gracza
        repaint(); // Odśwież panel po ruchu gracza
    }

    // Metoda do generowania mapy podłogi
    private int[][] generateFloorMap() {
        int[][] generatedMap = new int[400][2]; // 20x20 kafelków podłogi
        int index = 0;
        for (int x = 0; x < 20; x++) {
            for (int y = 0; y < 20; y++) {
                // Ustawianie współrzędnych każdego kafelka podłogi
                generatedMap[index][0] = x * 50; // Współrzędna x
                generatedMap[index][1] = y * 50; // Współrzędna y
                index++;
            }
        }
        return generatedMap;
    }


    public List<Point> getNeighbors(Point point) {
        List<Point> neighbors = new ArrayList<>();

        // Współrzędne sąsiednich punktów
        int[][] adjacentOffsets = {
                {-1, 0}, // lewy sąsiad
                {1, 0},  // prawy sąsiad
                {0, -1}, // górny sąsiad
                {0, 1}   // dolny sąsiad
        };

        // Sprawdź każdego sąsiada
        for (int[] offset : adjacentOffsets) {
            int neighborX = point.x + offset[0];
            int neighborY = point.y + offset[1];

            // Jeśli sąsiad znajduje się w granicach planszy i nie jest ścianą, dodaj go do listy sąsiadów
            if (neighborX >= 0 && neighborX < getWidth() && neighborY >= 0 && neighborY < getHeight() && !isWall(neighborX, neighborY)) {
                neighbors.add(new Point(neighborX, neighborY));
            }
        }

        return neighbors;
    }

    // Metoda sprawdzająca, czy dany punkt na planszy jest ścianą
    private boolean isWall(int x, int y) {
        // Sprawdzamy, czy punkt o współrzędnych (x, y) znajduje się w pokoj1.xz
        for (int[] coords : pokoj1.xz) {
            if (coords[0] == x && coords[1] == y) {
                return true; // Jeśli punkt jest w pokoj1.xz, uznajemy go za ścianę
            }
        }
        return false; // Jeśli punkt nie jest w pokoj1.xz, uznajemy go za wolne pole
    }

    private void skibidimapa() {
        int[] randomNumbers = new int[131];
        for (int i = 0; i < 131; i++) {
            randomNumbers[i] = 50 * (int) (floor(Math.random() * 18) + 1);
        }
        pokoj1.setxz(new int[][]{
                {randomNumbers[90],randomNumbers[91]},{randomNumbers[92],randomNumbers[93]},{randomNumbers[94],randomNumbers[95]},{randomNumbers[96],randomNumbers[97]},{randomNumbers[98],randomNumbers[99]},
                {randomNumbers[100],randomNumbers[101]},{randomNumbers[102],randomNumbers[103]},{randomNumbers[104],randomNumbers[105]},{0,0}, {50,0}, {100,0},{150,0},{200,0},{250,0},
                {300,0},{350,0},{400,0},{550,0},{600,0},{650,0},{700,0},{750,0},{800,0},{850,0},{900,0},{50,randomNumbers[0]},{100,randomNumbers[1]},{150,randomNumbers[8]},
                {200,randomNumbers[9]},{250,randomNumbers[10]},{300,randomNumbers[11]},{350,randomNumbers[12]},{400,randomNumbers[13]},{450,randomNumbers[14]},{500,randomNumbers[15]},
                {550,randomNumbers[16]},{600,randomNumbers[17]},{650,randomNumbers[18]},{700,randomNumbers[19]},{750,randomNumbers[20]},{800,randomNumbers[21]},{850,randomNumbers[22]},
                {900,randomNumbers[23]},{700,randomNumbers[5]},{700,randomNumbers[7]},{750,randomNumbers[6]},{800,randomNumbers[4]},{850,randomNumbers[3]},{900,randomNumbers[2]},
                {50,randomNumbers[24]},{100,randomNumbers[25]},{150,randomNumbers[26]},{200,randomNumbers[27]},{250,randomNumbers[28]},{300,randomNumbers[29]},{350,randomNumbers[30]},
                {400,randomNumbers[31]},{450,randomNumbers[32]},{500,randomNumbers[33]},{550,randomNumbers[34]},{600,randomNumbers[35]},{650,randomNumbers[36]},{700,randomNumbers[37]},
                {750,randomNumbers[38]},{800,randomNumbers[39]},{850,randomNumbers[40]},{900,randomNumbers[41]},{50,randomNumbers[42]},{100,randomNumbers[43]},{150,randomNumbers[44]},
                {200,randomNumbers[45]},{250,randomNumbers[46]},{300,randomNumbers[47]},{350,randomNumbers[48]},{400,randomNumbers[49]},{450,randomNumbers[50]},{500,randomNumbers[51]},
                {550,randomNumbers[52]},{600,randomNumbers[53]},{650,randomNumbers[54]},{700,randomNumbers[55]},{750,randomNumbers[56]},{800,randomNumbers[57]},{850,randomNumbers[58]},
                {900,randomNumbers[59]},{700,randomNumbers[60]},{700,randomNumbers[61]},{750,randomNumbers[62]},{800,randomNumbers[63]},{850,randomNumbers[64]},{900,randomNumbers[65]},
                {950,0},{0,0}, {0,50}, {0,100}, {0,150}, {0,200}, {0,250}, {0,300}, {0,350}, {0,400},  {0,550}, {0,600}, {0,650}, {0,700}, {0,750}, {0,800}, {0,850}, {0,900},
                {0,950},{950,0},{50,randomNumbers[66]},{100,randomNumbers[67]},{150,randomNumbers[68]},{200,randomNumbers[69]},{250,randomNumbers[70]},{300,randomNumbers[71]},
                {350,randomNumbers[72]},{400,randomNumbers[73]},{450,randomNumbers[74]},{500,randomNumbers[75]},{550,randomNumbers[76]},{600,randomNumbers[77]},{650,randomNumbers[78]},
                {700,randomNumbers[79]},{750,randomNumbers[80]},{800,randomNumbers[81]},{850,randomNumbers[82]},{900,randomNumbers[83]},{50,randomNumbers[84]},{100,randomNumbers[85]},
                {150,randomNumbers[86]},{200,randomNumbers[87]},{250,randomNumbers[88]},{300,randomNumbers[89]},
                {950,50}, {950,100}, {950,150}, {950,200}, {950,250}, {950,300}, {950,350}, {950,400},{950,550}, {950,600}, {950,650}, {950,700}, {950,750}, {950,800},
                {950,850}, {950,900}, {950,950},{0,950}, {50,950}, {100,950}, {150,950}, {200,950}, {250,950}, {300,950}, {350,950}, {400,950},{550,950}, {600,950},
                {650,950}, {700,950}, {750,950}, {800,950}, {850,950}, {900,950}, {950,950}
        });

    }
    private void regenerateMap() {
        skibidimapa();
        repaint();
    }
    class Tile{ private int x,y;
        public int getX() {return x;}

        public void setX(int x) {this.x = x;}

        public int getY() {return y;}
        public void setY(int y) {this.y = y;}
    }

    Tile whichTileClicked (int xPixel, int yPixel){

        Tile returnValue = new Tile();
        returnValue.x = (int) floor( ((float) xPixel / 50) );
        returnValue.y = (int) floor( ((float) yPixel / 50) );
        return returnValue;
    }

    // Metoda mouseClicked z interfejsu MouseListener
    @Override
    public void mouseClicked(MouseEvent e) {
        // Pobierz współrzędne kliknięcia myszą
        int mouseX = e.getX();
        int mouseY = e.getY();

        Tile tile = whichTileClicked(mouseX,mouseY);

        // Sprawdź, który kafelek został kliknięty
        List<Point> shortestPath = null;
        int tileX = tile.x;
        int tileY = tile.y;

        // Sprawdź, czy współrzędne kliknięcia są wewnątrz kafelka
        // Kafelek został kliknięty
        highlightedX = tileX * 50; // Ustaw współrzędną x klikniętego kafelka w pixelach
        highlightedY = tileY * 50; // Ustaw współrzędną y klikniętego kafelka w pixelach
        repaint(); // Odśwież panel, aby pokazać podświetlony kafelek
        // Oblicz najkrótszą ścieżkę za pomocą algorytmu A*
        shortestPath = findShortestPath(new Point(player.getX(), player.getY()), new Point(highlightedX, highlightedY));

        // Wyświetl ścieżkę w konsoli (do celów testowych)
        System.out.println("Najkrótsza ścieżka:");
        for (Point point : shortestPath) {
            System.out.println("(" + point.x + ", " + point.y + ")");
        }
        movePlayerAlongPath(shortestPath);
    }



    // Metoda do znalezienia najkrótszej ścieżki za pomocą algorytmu A*
    public List<Point> findShortestPath(Point start, Point goal) {
        // Inicjalizacja listy, która będzie przechowywać najkrótszą ścieżkę
        List<Point> shortestPath = new ArrayList<>();

        // Kolejka priorytetowa do przechowywania wierzchołków i ich odległości od źródła
        PriorityQueue<Node> pq = new PriorityQueue<>(Comparator.comparingInt(node -> node.distance));

        // Mapa odległości od źródła
        int[][] distances = new int[20][20]; // Wymiary planszy w jednostkach kafelków

        // Inicjalizacja odległości jako nieskończoność
        for (int x = 0; x < 20; x++) {
            for (int y = 0; y < 20; y++) {
                distances[x][y] = Integer.MAX_VALUE;
            }
        }

        // Inicjalizacja odległości od źródła dla punktu startowego jako 0
        distances[start.x / 50][start.y / 50] = 0; // Dzielimy przez 50, aby przekonwertować piksele na kafelki

        // Dodanie punktu startowego do kolejki priorytetowej
        pq.add(new Node(new Point(start.x / 50, start.y / 50), 0)); // Dzielimy przez 50, aby przekonwertować piksele na kafelki

        // Dopóki kolejka priorytetowa nie jest pusta
        while (!pq.isEmpty()) {
            // Pobierz wierzchołek o najmniejszej odległości od źródła
            Node currentNode = pq.poll();

            // Jeśli dotarliśmy do celu, zakończ algorytm
            if (currentNode.point.equals(new Point(goal.x / 50, goal.y / 50))) { // Dzielimy przez 50, aby przekonwertować piksele na kafelki
                // Odtwórz najkrótszą ścieżkę
                while (currentNode != null) {
                    shortestPath.add(0, new Point(currentNode.point.x * 50, currentNode.point.y * 50)); // Mnożymy przez 50, aby przekonwertować kafelki na piksele
                    currentNode = currentNode.parent;
                }
                return shortestPath;
            }

            // Sprawdź sąsiadów aktualnego wierzchołka
            for (Point neighbor : getNeighbors(currentNode.point)) {
                // Oblicz nową odległość od źródła
                int newDistance = distances[currentNode.point.x][currentNode.point.y] + 1; // Załóżmy, że każda krawędź ma wagę 1

                // Jeśli nowa odległość jest krótsza niż obecna odległość
                if (newDistance < distances[neighbor.x][neighbor.y]) {
                    // Zaktualizuj odległość
                    distances[neighbor.x][neighbor.y] = newDistance;
                    // Dodaj sąsiada do kolejki priorytetowej z nową odległością
                    pq.add(new Node(neighbor, newDistance, currentNode));
                }
            }
        }

        // Jeśli nie udało się znaleźć ścieżki, zwróć pustą listę
        return shortestPath;
    }

    // Pozostałe metody z interfejsu MouseListener, możesz je zaimplementować pustymi ciałami

    @Override
    public void mousePressed(MouseEvent e) {}

    @Override
    public void mouseReleased(MouseEvent e) {}

    @Override
    public void mouseEntered(MouseEvent e) {}

    @Override
    public void mouseExited(MouseEvent e) {}

    // Pozostałe metody z interfejsu KeyListener, możesz je zaimplementować pustymi ciałami

    @Override
    public void keyReleased(KeyEvent e) {}

    @Override
    public void keyTyped(KeyEvent e ) {}
    private void movePlayerAlongPath(List<Point> path) {
        // If the shortest path is empty or null, return
        if (path == null || path.isEmpty()) {
            return;
        }

        // Iterate through the path and move the player
        for (Point point : path) {
            int newX = point.x * 50; // Convert coordinates to pixels
            int newY = point.y * 50;

            // Check if the new position is a valid move (not a wall)
            if (!isWall(newX, newY)) {
                // Move the player to the new position
                player.setX(newX);
                player.setY(newY);
                repaint(); // Refresh the panel to show the player's new position
                // Optional: Add a delay between each move for better visualization
                try {
                    Thread.sleep(2000); // Adjust the delay time as needed
                } catch (InterruptedException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }

    // Przykładowe użycie klasy GameBoard
    public static void main(String[] args) {
        JFrame frame = new JFrame("Game Board");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        GameBoard gameBoard = new GameBoard();
        frame.add(gameBoard);
        frame.setSize(1000, 1000);
        frame.setVisible(true);
    }
}