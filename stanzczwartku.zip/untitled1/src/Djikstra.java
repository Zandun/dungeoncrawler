import java.util.*;

public class Djikstra {
    private int[][] graph;
    private int size;

    public Djikstra(int[][] graph) {
        this.graph = graph;
        this.size = graph.length;
    }

    // Metoda do znajdowania najkrótszej ścieżki za pomocą algorytmu Dijkstry
    public List<Integer> shortestPath(int start, int end) {
        // Inicjalizacja tablicy odległości z maksymalnymi wartościami
        int[] distances = new int[size];
        Arrays.fill(distances, Integer.MAX_VALUE);

        // Inicjalizacja tablicy odwiedzonych wierzchołków
        boolean[] visited = new boolean[size];

        // Inicjalizacja tablicy poprzedników do śledzenia ścieżki
        int[] predecessor = new int[size];
        Arrays.fill(predecessor, -1);

        // Ustawienie odległości do wierzchołka startowego na 0
        distances[start] = 0;

        // Algorytm Dijkstry
        for (int i = 0; i < size - 1; i++) {
            // Znajdź wierzchołek o najmniejszej odległości
            int minVertex = minDistance(distances, visited);

            // Oznacz wierzchołek o minimalnej odległości jako odwiedzony
            visited[minVertex] = true;

            // Aktualizacja odległości dla sąsiednich wierzchołków
            for (int j = 0; j < size; j++) {
                if (!visited[j] && graph[minVertex][j] != 0 &&
                        distances[minVertex] != Integer.MAX_VALUE &&
                        distances[minVertex] + graph[minVertex][j] < distances[j]) {
                    distances[j] = distances[minVertex] + graph[minVertex][j];
                    predecessor[j] = minVertex;
                }
            }
        }

        // Budowanie najkrótszej ścieżki
        List<Integer> path = new ArrayList<>();
        int current = end;
        while (current != -1) {
            path.add(current);
            current = predecessor[current];
        }
        Collections.reverse(path);

        return path;
    }

    // Metoda pomocnicza do znalezienia wierzchołka o najmniejszej odległości
    private int minDistance(int[] distances, boolean[] visited) {
        int min = Integer.MAX_VALUE;
        int minIndex = -1;

        for (int i = 0; i < size; i++) {
            if (!visited[i] && distances[i] <= min) {
                min = distances[i];
                minIndex = i;
            }
        }

        return minIndex;
    }
}