import java.awt.Point;

public class Node {
    public Point point; // Współrzędne wierzchołka
    public int distance; // Odległość od źródła
    public Node parent; // Poprzedni wierzchołek w najkrótszej ścieżce

    public Node(Point point, int distance) {
        this.point = point;
        this.distance = distance;
    }

    public Node(Point point, int distance, Node parent) {
        this.point = point;
        this.distance = distance;
        this.parent = parent;
    }
}