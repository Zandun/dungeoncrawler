
public class Room {
    public static class sciana {
        int xz[][];
        public void Room( int[][] roomType) {
            this.xz = roomType;
        }
        public int[][] x() {
            return xz;
        }
        public void setxz(int[][] xz) {
            this.xz =xz;
        }
    }
    public static class podloga {
        int xz[][];
        public void Room( int[][] roomType) {
            this.xz = roomType;
        }
        public int[][] x() {
            return xz;
        }
        public void setxz(int[][] xz) {
            this.xz =xz;
        }
    }
    public static class schodzygora {
        int xz[][];
        public void Room( int[][] roomType) {
            this.xz = roomType;
        }
        public int[][] x() {
            return xz;
        }
        public void setxz(int[][] xz) {
            this.xz =xz;
        }
    }
    public static class schodzydol {
        int xz[][];
        public void Room( int[][] roomType) {
            this.xz = roomType;
        }
        public int[][] x() {
            return xz;
        }
        public void setxz(int[][] xz) {
            this.xz =xz;
        }
    }

}
