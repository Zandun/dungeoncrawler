public class Player {
    private int x; // Współrzędna x gracza
    private int y; // Współrzędna y gracza

    // Konstruktor
    public Player(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // Metoda do przemieszczania gracza w górę
    public void moveUp() {
        y =y-50;
    }

    // Metoda do przemieszczania gracza w dół
    public void moveDown() {
         y =y+50;
    }

    // Metoda do przemieszczania gracza w lewo
    public void moveLeft() {
        x =x-50;
    }

    // Metoda do przemieszczania gracza w prawo
    public void moveRight() {
        x =x+50;
    }

    // Getter dla współrzędnej x
    public int getX() {
        return x;
    }

    // Getter dla współrzędnej y
    public int getY() {
        return y;
    }

    public void setX(int newx) {
        this.x = newx;
    }
    public void setY(int newy) {
        this.y = newy;
    }
}